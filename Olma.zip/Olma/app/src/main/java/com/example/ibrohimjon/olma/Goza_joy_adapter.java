package com.example.ibrohimjon.olma;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Goza_joy_adapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<Goza_joy_list> goza_joy_lists;

    public Goza_joy_adapter(Context context, int layout, ArrayList<Goza_joy_list> goza_joy_lists) {
        this.context = context;
        this.layout = layout;
        this.goza_joy_lists = goza_joy_lists;
    }

    @Override
    public int getCount() {
        return goza_joy_lists.size();
    }

    @Override
    public Object getItem(int position) {
        return goza_joy_lists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txt_goza_tartib, txt_goza_name, txt_goza_id;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

            holder.txt_goza_id = (TextView) row.findViewById(R.id.txt_goza_joy_item_id);
            holder.txt_goza_tartib = (TextView) row.findViewById(R.id.txt_goza_joy_tartib);
            holder.txt_goza_name = (TextView) row.findViewById(R.id.txt_goza_joy_nomi);

            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        Goza_joy_list goza_joy_list = goza_joy_lists.get(position);

        holder.txt_goza_name.setText(goza_joy_list.getJoy_nomi());
        holder.txt_goza_tartib.setText(String.valueOf(goza_joy_list.getTartib()));

        return row;
    }
}
