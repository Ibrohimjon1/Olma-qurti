package com.example.ibrohimjon.olma;

import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Goza_joy_royh extends AppCompatActivity {

    Goza_joy_adapter adapter = null;
    ListView list_View;
    ArrayList<Goza_joy_list> joy_list;
    ImageView btn_kirim_add;
    TextView txt_goza_joy_yoq;
    int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goza_joy_activity);

        joy_list = new ArrayList<>();
        list_View = (ListView) findViewById(R.id.list_view_goza_joy_nomi);
        btn_kirim_add = (ImageView) findViewById(R.id.btn_goza_joy_add);
        txt_goza_joy_yoq = (TextView) findViewById(R.id.txt_goza_joy_yoq);

        adapter = new Goza_joy_adapter(this, R.layout.goza_joy_items, joy_list);
        list_View.setAdapter(adapter);

        Bundle extras = getIntent().getExtras();// get intent data
        if (extras != null) {
            // get id and message
            id = extras.getInt("not_Id");
        }
        NotificationManager myNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        // remove the notification with the specific id
        myNotificationManager.cancel(id);

        try {
            getdata("SELECT DISTINCT joy_nomi FROM GOZA");
        } catch (Exception e) {
            e.printStackTrace();
        }

        list_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
                TextView textView = (TextView) view.findViewById(R.id.txt_goza_joy_nomi);
                String joy_nomi = textView.getText().toString();
                Intent intent = new Intent(Goza_joy_royh.this, Goza_add.class);
                intent.putExtra("joy_nomi",joy_nomi);
                startActivity(intent);
            }
        });

        list_View.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                CharSequence[] items = {"O'chirish"};
                AlertDialog.Builder dialog = new AlertDialog.Builder(Goza_joy_royh.this);
                final TextView txt_viloyat = (TextView) view.findViewById(R.id.txt_goza_joy_nomi);
//                TextView txt_id = (TextView) view.findViewById(R.id.txt_viloyat_id);
//                final int id3 = Integer.parseInt(txt_id.getText().toString());
                dialog.setTitle("Tanlang");
                dialog.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int item) {

                        if (item == 0) {
                            //Update
                            //showDialog_Update(Goza_joy_royh.this, id3, txt_viloyat.getText().toString().trim());
//                        } else {
                            // delete
                            showDialogDelete_for_one(txt_viloyat.getText().toString().trim());
                        }
                    }
                });
                dialog.show();
                return true;
            }
        });

        btn_kirim_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Goza_joy_royh.this, Goza_add_joy_nomi.class);
                intent.putExtra("goza","goza");
                startActivity(intent);
            }
        });
    }

    private void showDialogDelete_for_one(final String joy_nomi) {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Goza_joy_royh.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("Ha", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                try {
                    Asosiy_oyna.myDataBase.insert_shahar(joy_nomi, "DELETE FROM GOZA WHERE joy_nomi = ?");
                    Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli o'chirildi!!!", Toast.LENGTH_SHORT).show();
                } catch (Exception error) {
                    error.printStackTrace();
                }
                getdata("SELECT DISTINCT joy_nomi FROM GOZA");
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }


    @Override
    protected void onResume() {
        super.onResume();
        try {
           getdata("SELECT DISTINCT joy_nomi FROM GOZA");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getdata(String sql) {
        Cursor cursor = Asosiy_oyna.myDataBase.getData(sql);
        int id_soni = 0;
        joy_list.clear();
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                int tartib = id_soni++;
                String joy_nomi = cursor.getString(0);

                joy_list.add(new Goza_joy_list(joy_nomi, tartib));
            } while (cursor.moveToNext());
            adapter.notifyDataSetChanged();
            txt_goza_joy_yoq.setVisibility(View.GONE);
            return 1;
        }else {
            joy_list.clear();
            adapter.notifyDataSetChanged();
            txt_goza_joy_yoq.setText("G'o'za tunlamida \n hech nima yo'q!" +
                    "\n\n\nYangi ma'lumot kiritish uchun \n quyidagi + tugmani bosing!");
            txt_goza_joy_yoq.setVisibility(View.VISIBLE);
            return 0;
        }
    }
}
