package com.example.ibrohimjon.olma;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Asosiy_oyna extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener  {

    public static MyDataBase myDataBase;
    Button btn_sozlama;
    Button btn_goza;
    final int DIALOG_EXIT = 1, ABOUT = 2;
    boolean chiqish = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navigation_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        btn_goza = (Button) findViewById(R.id.btn_goza);
        btn_sozlama = (Button) findViewById(R.id.btn_sozlama);

        myDataBase = new MyDataBase(this, "Goza_tullam.sqlite", null, 1);
        myDataBase.queryData("CREATE TABLE IF NOT EXISTS VILOYAT (Id INTEGER PRIMARY KEY AUTOINCREMENT, viloyat VARCHAR)");
        myDataBase.queryData("CREATE TABLE IF NOT EXISTS SHAHAR1 (Id INTEGER PRIMARY KEY AUTOINCREMENT, shahar VARCHAR)");
        myDataBase.queryData("CREATE TABLE IF NOT EXISTS KOCHA (Id INTEGER PRIMARY KEY AUTOINCREMENT, kocha VARCHAR)");
        myDataBase.queryData("CREATE TABLE IF NOT EXISTS GOZA (Id INTEGER PRIMARY KEY AUTOINCREMENT, sana DATE, kop_yillik VARCHAR, foy_xar VARCHAR, xaqiqiy_xarorat VARCHAR, foy_xar_yig VARCHAR, goza VARCHAR, joy_nomi VARCHAR)");
        myDataBase.queryData("CREATE TABLE IF NOT EXISTS KUZGI (Id INTEGER PRIMARY KEY AUTOINCREMENT, sana DATE, kop_yillik VARCHAR, foy_xar VARCHAR, xaqiqiy_xarorat VARCHAR, foy_xar_yig VARCHAR, goza VARCHAR, joy_nomi VARCHAR)");

        btn_goza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Asosiy_oyna.this, Goza_joy_royh.class);
                startActivity(intent);
            }
        });

        btn_sozlama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Asosiy_oyna.this, Kuzgi_joy_royh.class);
                startActivity(intent);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        assert drawer != null;
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        assert navigationView != null;
        navigationView.setNavigationItemSelectedListener(this);

    }

    private boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        DrawerLayout drawer1 = (DrawerLayout) findViewById(R.id.drawer_layout);
        assert drawer1 != null;
        if (drawer1.isDrawerOpen(GravityCompat.START)) {
            drawer1.closeDrawer(GravityCompat.START);
        } else {
            showDialog(DIALOG_EXIT);
            if (chiqish) {
                super.onBackPressed();
            }
        }
//
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//        } else {
//            if (doubleBackToExitPressedOnce) {
//                super.onBackPressed();
//                return;
//            }
//            doubleBackToExitPressedOnce = true;
////            Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
//
//            new Handler().postDelayed(new Runnable() {
//
//                @Override
//                public void run() {
//                    doubleBackToExitPressedOnce = false;
//                }
//            }, 2000);
//        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_viloyat) {
            Intent intent = new Intent(Asosiy_oyna.this, Viloyat_nomi.class);
            startActivity(intent);
        } else if (id == R.id.nav_shahar) {
            Intent intent = new Intent(Asosiy_oyna.this, Shahar_nomi.class);
            startActivity(intent);
        } else if (id == R.id.nav_kocha) {
            Intent intent = new Intent(Asosiy_oyna.this, Kocha_nomi.class);
            startActivity(intent);
        } else if (id == R.id.nav_goza) {
            Intent intent = new Intent(Asosiy_oyna.this, Ortacha_xarorat.class);
            startActivity(intent);
        } else if (id == R.id.nav_setting) {
            Intent intent = new Intent(Asosiy_oyna.this, Settings.class);
            startActivity(intent);
        } else if (id == R.id.nav_about) {
            Intent intent = new Intent(Asosiy_oyna.this, Dastur_haqiqa.class);
            startActivity(intent);
        } else if(id == R.id.nav_goza_about){
            Intent intent = new Intent(Asosiy_oyna.this, Goza_about.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    protected Dialog onCreateDialog(int id) {
        AlertDialog.Builder adb = new AlertDialog.Builder(this);
        switch (id) {
            case DIALOG_EXIT:
                adb.setMessage(R.string.exit);
                adb.setTitle(R.string.sarlavha);
                adb.setIcon(R.drawable.soroq);
                adb.setPositiveButton("Ha", myClickListener);
                adb.setNegativeButton("Yo'q", myClickListener);
                break;
            case ABOUT:

                break;
        }
        return adb.create();
    }
    DialogInterface.OnClickListener myClickListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case Dialog.BUTTON_POSITIVE:
                    chiqish = true;
                    finish();
                    break;
                case Dialog.BUTTON_NEUTRAL:
                    chiqish = false;
                    break;

            }
        }
    };
}
