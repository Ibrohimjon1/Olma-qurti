package com.example.ibrohimjon.olma;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Settings extends AppCompatActivity{

    Button btn_color_picker, btn_saqlash;
    CheckBox checkBox;
    String rang = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

//        btn_color_picker = (Button) findViewById(R.id.btn_color_picker);
        btn_saqlash = (Button) findViewById(R.id.btn_saqlash);
        checkBox = (CheckBox) findViewById(R.id.checkbox_message);

        String colorCode = String.valueOf(R.color.colorBackground);

        SharedPreferences preferences = getSharedPreferences("setting", Context.MODE_PRIVATE);

        String xabar = preferences.getString("xabar","1");
//        String rang_color = preferences.getString("rang",colorCode);

        if (xabar.equals("1")){
            checkBox.setChecked(true);
        } else {
            checkBox.setChecked(false);
        }

//        btn_color_picker.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                    int colorCode = R.color.colorBackground;
//
//                    //pick a color (changed in the UpdateColor listener)
//                    new ColorPickerDialog(Settings.this, new UpdateColor(), colorCode).show();
//            }
//        });

        btn_saqlash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences preferences = getSharedPreferences("setting", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = preferences.edit();
                if (checkBox.isChecked()){
                    editor.putString("xabar", "1");
                } else {
                    editor.putString("xabar", "0");
                }
//                editor.putString("rang", rang);
                editor.apply();
                finish();
            }
        });
    }

    public class UpdateColor implements ColorPickerDialog.OnColorChangedListener {
        public void colorChanged(int color) {
            //ShowColor.setBackgroundColor(color);
            rang = String.valueOf(color);
            //show the color value
//            R.color.colorBackground = color;
        }
    }

}
