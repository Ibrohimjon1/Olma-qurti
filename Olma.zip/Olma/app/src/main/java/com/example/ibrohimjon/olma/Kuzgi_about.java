package com.example.ibrohimjon.olma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Kuzgi_about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kuzgi_about_activity);
    }
}
